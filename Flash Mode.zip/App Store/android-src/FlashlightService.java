package com.flashmode.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;

public class FlashlightService extends Service {
    public static final String ACTION_ON="com.flashmode.app.TORCH_ON", ACTION_OFF="com.flashmode.app.TORCH_OFF", ACTION_PATTERN="com.flashmode.app.PATTERN", ACTION_STOP="com.flashmode.app.STOP";
    private static final String CHANNEL="flashlight_running";
    private CameraManager cameraManager; private String cameraId; private final Handler handler=new Handler(Looper.getMainLooper());
    private long[] sequence={100,100}; private int index=0, toggles=0, finiteToggles=0; private boolean loop=true, torchOn=false; private long autoOffMs=0; private Runnable ticker, autoOff;

    @Override public void onCreate(){super.onCreate();cameraManager=(CameraManager)getSystemService(Context.CAMERA_SERVICE);createChannel();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;String action=intent.getAction();
        if(ACTION_STOP.equals(action)||ACTION_OFF.equals(action)){stopPatternTasks();setTorch(false);stopForeground(true);stopSelf();return START_NOT_STICKY;}
        if(ACTION_ON.equals(action)){stopPatternTasks();startForeground(4101,notification("Flashlight is on"));setTorch(true);return START_STICKY;}
        if(ACTION_PATTERN.equals(action)){startForeground(4101,notification("Flashlight pattern running · works with screen off"));stopPatternTasks();
            try{JSONArray a=new JSONArray(intent.getStringExtra("sequence"));sequence=new long[Math.max(1,a.length())];for(int j=0;j<sequence.length;j++)sequence[j]=Math.max(35,a.optLong(j,100));}catch(Exception e){sequence=new long[]{100,100};}
            loop=intent.getBooleanExtra("loop",true);autoOffMs=intent.getLongExtra("autoOffMs",0);finiteToggles=intent.getIntExtra("finiteToggles",0);index=0;toggles=0;
            ticker=new Runnable(){public void run(){if(finiteToggles>0&&toggles>=finiteToggles){setTorch(false);stopForeground(true);stopSelf();return;}setTorch(!torchOn);toggles++;long delay=sequence[index%sequence.length];index++;if(!loop&&finiteToggles==0&&index>=sequence.length){setTorch(false);stopForeground(true);stopSelf();return;}handler.postDelayed(this,delay);}};handler.post(ticker);
            if(autoOffMs>0){autoOff=new Runnable(){public void run(){stopPatternTasks();setTorch(false);stopForeground(true);stopSelf();}};handler.postDelayed(autoOff,autoOffMs);}return START_STICKY;}
        return START_NOT_STICKY;
    }
    private void stopPatternTasks(){if(ticker!=null)handler.removeCallbacks(ticker);if(autoOff!=null)handler.removeCallbacks(autoOff);ticker=null;autoOff=null;}
    private void setTorch(boolean enabled){try{if(cameraId==null){for(String id:cameraManager.getCameraIdList()){CameraCharacteristics c=cameraManager.getCameraCharacteristics(id);Boolean flash=c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);Integer facing=c.get(CameraCharacteristics.LENS_FACING);if(Boolean.TRUE.equals(flash)&&facing!=null&&facing==CameraCharacteristics.LENS_FACING_BACK){cameraId=id;break;}}}if(cameraId==null)throw new IllegalStateException("No rear camera with LED flash found");cameraManager.setTorchMode(cameraId,enabled);torchOn=enabled;}catch(Exception e){torchOn=false;stopPatternTasks();stopForeground(true);stopSelf();}}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Flashlight control",NotificationManager.IMPORTANCE_LOW);c.setDescription("Keeps flashlight modes running when the screen is off");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification notification(String text){Intent stop=new Intent(this,FlashlightService.class);stop.setAction(ACTION_STOP);PendingIntent pi=PendingIntent.getService(this,4102,stop,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));return new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Flash Mode").setContentText(text).setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).addAction(android.R.drawable.ic_media_pause,"STOP",pi).build();}
    @Override public void onDestroy(){stopPatternTasks();setTorch(false);super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
