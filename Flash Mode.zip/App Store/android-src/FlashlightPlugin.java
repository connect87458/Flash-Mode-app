package com.flashmode.app;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.PermissionState;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import org.json.JSONArray;

@CapacitorPlugin(name = "Flashlight", permissions = {
    @Permission(alias = "camera", strings = { Manifest.permission.CAMERA })
})
public class FlashlightPlugin extends Plugin {
    @PluginMethod
    public void requestCameraPermission(PluginCall call) {
        if (getPermissionState("camera") == PermissionState.GRANTED) { call.resolve(); return; }
        requestPermissionForAlias("camera", call, "cameraPermissionResult");
    }

    @PermissionCallback
    private void cameraPermissionResult(PluginCall call) {
        if (getPermissionState("camera") == PermissionState.GRANTED) call.resolve();
        else call.reject("Camera permission is required to control the flashlight.");
    }

    @PluginMethod
    public void setTorch(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) { requestPermissionForAlias("camera", call, "setTorchAfterPermission"); return; }
        applyTorch(call, call.getBoolean("enabled", false));
    }

    @PermissionCallback
    private void setTorchAfterPermission(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) { call.reject("Camera permission denied."); return; }
        applyTorch(call, call.getBoolean("enabled", false));
    }

    private void applyTorch(PluginCall call, boolean enabled) {
        Intent i = new Intent(getContext(), FlashlightService.class);
        i.setAction(enabled ? FlashlightService.ACTION_ON : FlashlightService.ACTION_OFF);
        try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && enabled) getContext().startForegroundService(i); else getContext().startService(i); call.resolve(); }
        catch (Exception e) { call.reject("Unable to control flashlight: " + e.getMessage()); }
    }

    @PluginMethod
    public void startPattern(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) { requestPermissionForAlias("camera", call, "startPatternAfterPermission"); return; }
        startPatternService(call);
    }

    @PermissionCallback
    private void startPatternAfterPermission(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) { call.reject("Camera permission denied."); return; }
        startPatternService(call);
    }

    private void startPatternService(PluginCall call) {
        JSONArray seq = call.getArray("sequence");
        Intent i = new Intent(getContext(), FlashlightService.class);
        i.setAction(FlashlightService.ACTION_PATTERN);
        i.putExtra("sequence", seq == null ? "[100,100]" : seq.toString());
        i.putExtra("loop", call.getBoolean("loop", true));
        i.putExtra("autoOffMs", call.getLong("autoOffMs", 0L));
        i.putExtra("finiteToggles", call.getInt("finiteToggles", 0));
        try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getContext().startForegroundService(i); else getContext().startService(i); call.resolve(); }
        catch (Exception e) { call.reject("Unable to start flashlight pattern: " + e.getMessage()); }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Intent i = new Intent(getContext(), FlashlightService.class); i.setAction(FlashlightService.ACTION_STOP);
        try { getContext().startService(i); call.resolve(); } catch (Exception e) { call.reject(e.getMessage()); }
    }
}
